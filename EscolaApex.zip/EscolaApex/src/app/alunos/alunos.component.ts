import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alunos',
  templateUrl: './alunos.component.html',
  styleUrls: ['./alunos.component.css']
})
export class AlunosComponent implements OnInit {

  public titulo = 'Alunos';

  public alunos = [
    {nome:'Diego', telefone:'12345678900', cpf:'12345678900'},
    {nome:'Matheus', telefone:'12345678901', cpf:'12345678901'},
    {nome:'Felipe', telefone:'12345678902', cpf:'12345678902'},
    {nome:'Marcela', telefone:'12345678903', cpf:'12345678903'}

  ];
  
  constructor() { }

  ngOnInit(): void {
  }

}
