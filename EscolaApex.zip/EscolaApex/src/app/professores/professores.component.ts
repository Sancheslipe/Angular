import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-professores',
  templateUrl: './professores.component.html',
  styleUrls: ['./professores.component.scss']
})
export class ProfessoresComponent implements OnInit {

  public titulo = 'Professores';

  public professores = [
    {nome:'Ralf', telefone:'12345678910', cpf:'12345628900'},
    {nome:'Luiz', telefone:'12345678911', cpf:'12345628901'},
    {nome:'DIego', telefone:'12345678912', cpf:'12345278902'},
    {nome:'Marcela', telefone:'12345678913', cpf:'12325678903'}

  ];
  constructor() { }

  ngOnInit() {
  }

}
